import pandas as pd

# Read CSV file
df = pd.read_csv('example.csv')

# Display DataFrame
print(df)