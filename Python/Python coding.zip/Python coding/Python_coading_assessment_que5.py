power = lambda x, n: x**n
result = power(2, 3)
print("2^3 =", result)


