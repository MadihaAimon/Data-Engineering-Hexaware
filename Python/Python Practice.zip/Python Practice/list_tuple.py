list_num = [1,2,3,4]
tup_num = (1,2,3,4)


list_num[2] = 5
print(list_num)

print(list_num)
print(tup_num)

print(type(list_num))
print(type(tup_num))