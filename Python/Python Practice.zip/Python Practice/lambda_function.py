def square():
    square = lambda x: x ** 2
    print(square(5))


square()
