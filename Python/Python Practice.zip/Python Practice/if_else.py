a = 33

# if
if a>23:
  print("a")

# if else
b = 33
if b > a:
  print("b is greater than a")
elif a == b:
  print("a and b are equal")



